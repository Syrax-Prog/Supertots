-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Sep 02, 2025 at 04:55 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supertots`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `activityID` int(11) NOT NULL,
  `activityName` text NOT NULL,
  `venue` text NOT NULL,
  `descA` text NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `startregisterdate` date NOT NULL,
  `endregisterdate` date NOT NULL,
  `payment` varchar(1000) NOT NULL,
  `totalParticipant` int(11) NOT NULL,
  `images` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`activityID`, `activityName`, `venue`, `descA`, `startdate`, `enddate`, `startregisterdate`, `endregisterdate`, `payment`, `totalParticipant`, `images`) VALUES
(7, 'Story Time', 'Library', 'A fun story time session for preschool children.', '2024-07-30', '2024-07-30', '2024-05-20', '2024-05-05', '0.00', 20, NULL),
(11, 'Mini Science Fair', 'Classroom', 'Simple science experiments and demonstrations.', '2024-11-15', '2024-11-15', '2024-10-01', '2024-11-05', '2.00', 15, NULL),
(12, 'sesfs', 'eq2q2ee', 'eqeq2e', '2024-07-25', '2024-07-26', '2024-07-17', '2024-07-18', '200', 20, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `activity_child`
--

CREATE TABLE `activity_child` (
  `acID` int(11) NOT NULL,
  `childid` varchar(6) NOT NULL,
  `activityid` int(11) NOT NULL,
  `paymentStatus` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_child`
--

INSERT INTO `activity_child` (`acID`, `childid`, `activityid`, `paymentStatus`) VALUES
(35, 'CH0001', 7, 'Free'),
(38, 'CH0004', 11, 'Not Paid'),
(42, 'CH0008', 11, 'Paid'),
(44, 'CH0010', 7, 'Free'),
(45, 'CH0011', 7, 'Free'),
(46, 'CH0012', 7, 'Free'),
(47, 'CH0013', 7, 'Free'),
(49, 'CH0015', 7, 'Free'),
(52, 'CH0018', 11, 'Not Paid'),
(54, 'CH0020', 11, 'Not Paid'),
(55, 'CH0021', 11, 'Not Paid'),
(57, 'CH0023', 7, 'Free'),
(58, 'CH0024', 7, 'Free'),
(62, 'CH0028', 11, 'Paid'),
(70, 'CH0036', 7, 'Free'),
(71, 'CH0037', 11, 'Payed'),
(72, 'CH0038', 11, 'Not Paid'),
(74, 'CH0040', 7, 'Free'),
(78, 'CH0044', 7, 'Free'),
(80, 'CH0046', 7, 'Free'),
(84, 'CH0050', 11, 'Paid'),
(85, 'CH0051', 11, 'Paid'),
(99, 'CH0002', 7, 'Free');

-- --------------------------------------------------------

--
-- Table structure for table `activity_teacher`
--

CREATE TABLE `activity_teacher` (
  `atID` int(11) NOT NULL,
  `staffid` varchar(6) NOT NULL,
  `activityid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_teacher`
--

INSERT INTO `activity_teacher` (`atID`, `staffid`, `activityid`) VALUES
(5, 'TE0001', 1),
(6, 'TE0001', 7),
(7, 'TE0002', 3),
(8, 'TE0003', 4),
(9, 'TE0002', 5),
(10, 'AD0001', 7);

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendanceid` int(11) NOT NULL,
  `Adate` date NOT NULL,
  `Astatus` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendanceid`, `Adate`, `Astatus`) VALUES
(753, '2024-06-28', 'Absent'),
(754, '2024-06-28', 'Absent'),
(755, '2024-06-28', 'Absent'),
(756, '2024-06-28', 'Absent'),
(757, '2024-06-28', 'Absent'),
(758, '2024-06-28', 'Absent'),
(759, '2024-06-28', 'Absent'),
(760, '2024-06-28', 'Absent'),
(761, '2024-06-28', 'Absent'),
(762, '2024-06-28', 'Absent'),
(763, '2024-06-28', 'Absent'),
(764, '2024-06-28', 'Absent'),
(765, '2024-06-28', 'Absent'),
(766, '2024-06-28', 'Absent'),
(767, '2024-06-28', 'Absent'),
(768, '2024-06-28', 'Absent'),
(769, '2024-06-28', 'Absent'),
(770, '2024-06-28', 'Absent'),
(771, '2024-07-04', 'Absent'),
(772, '2024-07-04', 'Absent'),
(773, '2024-07-04', 'Absent'),
(774, '2024-07-04', 'Absent'),
(775, '2024-07-04', 'Absent'),
(776, '2024-07-04', 'Absent'),
(777, '2024-07-04', 'Absent'),
(778, '2024-07-04', 'Absent'),
(779, '2024-07-04', 'Absent'),
(780, '2024-07-04', 'Absent'),
(781, '2024-07-04', 'Absent'),
(782, '2024-07-04', 'Absent'),
(783, '2024-07-04', 'Absent'),
(784, '2024-07-04', 'Absent'),
(785, '2024-07-04', 'Absent'),
(786, '2024-07-04', 'Absent'),
(787, '2024-07-04', 'Absent'),
(788, '2024-07-04', 'Absent'),
(789, '2024-07-08', 'Absent'),
(790, '2024-07-08', 'Absent'),
(791, '2024-07-08', 'Absent'),
(792, '2024-07-08', 'Absent'),
(793, '2024-07-08', 'Absent'),
(794, '2024-07-08', 'Absent'),
(795, '2024-07-08', 'Absent'),
(796, '2024-07-08', 'Absent'),
(797, '2024-07-08', 'Absent'),
(798, '2024-07-08', 'Absent'),
(799, '2024-07-08', 'Absent'),
(800, '2024-07-08', 'Absent'),
(801, '2024-07-08', 'Absent'),
(802, '2024-07-08', 'Absent'),
(803, '2024-07-08', 'Absent'),
(804, '2024-07-08', 'Absent'),
(805, '2024-07-08', 'Absent'),
(806, '2024-07-08', 'Absent'),
(807, '2024-07-09', 'Absent'),
(808, '2024-07-09', 'Absent'),
(809, '2024-07-09', 'Absent'),
(810, '2024-07-09', 'Absent'),
(811, '2024-07-09', 'Absent'),
(812, '2024-07-09', 'Absent'),
(813, '2024-07-09', 'Absent'),
(814, '2024-07-09', 'Absent'),
(815, '2024-07-09', 'Absent'),
(816, '2024-07-09', 'Absent'),
(817, '2024-07-09', 'Absent'),
(818, '2024-07-09', 'Absent'),
(819, '2024-07-09', 'Absent'),
(820, '2024-07-09', 'Absent'),
(821, '2024-07-09', 'Absent'),
(822, '2024-07-09', 'Absent'),
(823, '2024-07-09', 'Absent'),
(824, '2024-07-09', 'Absent'),
(825, '2024-07-12', 'Absent'),
(826, '2024-07-12', 'Absent'),
(827, '2024-07-12', 'Absent'),
(828, '2024-07-12', 'Absent'),
(829, '2024-07-12', 'Absent'),
(830, '2024-07-12', 'Absent'),
(831, '2024-07-12', 'Absent'),
(832, '2024-07-12', 'Absent'),
(833, '2024-07-12', 'Absent'),
(834, '2024-07-12', 'Absent'),
(835, '2024-07-12', 'Absent'),
(836, '2024-07-12', 'Absent'),
(837, '2024-07-12', 'Absent'),
(838, '2024-07-12', 'Absent'),
(839, '2024-07-12', 'Absent'),
(840, '2024-07-12', 'Absent'),
(841, '2024-07-12', 'Absent'),
(842, '2024-07-14', 'Absent'),
(843, '2024-07-14', 'Absent'),
(844, '2024-07-14', 'Absent'),
(845, '2024-07-14', 'Absent'),
(846, '2024-07-14', 'Absent'),
(847, '2024-07-14', 'Absent'),
(848, '2024-07-14', 'Absent'),
(849, '2024-07-14', 'Absent'),
(850, '2024-07-14', 'Absent'),
(851, '2024-07-14', 'Absent'),
(852, '2024-07-14', 'Absent'),
(853, '2024-07-14', 'Absent'),
(854, '2024-07-14', 'Absent'),
(855, '2024-07-14', 'Absent'),
(856, '2024-07-14', 'Absent'),
(857, '2024-07-14', 'Absent'),
(858, '2024-07-14', 'Absent'),
(859, '2024-07-14', 'Absent'),
(860, '2024-07-14', 'Absent'),
(861, '2024-07-14', 'Absent'),
(862, '2024-07-14', 'Absent'),
(863, '2024-07-14', 'Absent'),
(864, '2024-07-14', 'Absent'),
(865, '2024-07-14', 'Absent'),
(866, '2024-07-14', 'Absent'),
(867, '2024-07-14', 'Absent'),
(868, '2024-07-14', 'Absent'),
(869, '2024-07-14', 'Absent'),
(870, '2024-07-14', 'Absent'),
(871, '2024-07-14', 'Absent'),
(872, '2024-07-14', 'Absent'),
(873, '2024-07-14', 'Absent'),
(874, '2024-07-14', 'Absent'),
(875, '2024-07-14', 'Absent'),
(876, '2024-07-14', 'Absent'),
(877, '2024-07-15', 'Absent'),
(878, '2024-07-15', 'Absent'),
(879, '2024-07-15', 'Absent'),
(880, '2024-07-15', 'Absent'),
(881, '2024-07-15', 'Absent'),
(882, '2024-07-15', 'Absent'),
(883, '2024-07-15', 'Absent'),
(884, '2024-07-15', 'Absent'),
(885, '2024-07-15', 'Absent'),
(886, '2024-07-15', 'Absent'),
(887, '2024-07-15', 'Absent'),
(888, '2024-07-15', 'Absent'),
(889, '2024-07-15', 'Absent'),
(890, '2024-07-15', 'Absent'),
(891, '2024-07-15', 'Absent'),
(892, '2024-07-15', 'Absent'),
(893, '2024-07-15', 'Absent'),
(894, '2024-07-15', 'Absent'),
(895, '2024-07-30', 'Absent'),
(896, '2024-07-30', 'Absent'),
(897, '2024-07-30', 'Absent'),
(898, '2024-07-30', 'Absent'),
(899, '2024-07-30', 'Absent'),
(900, '2024-07-30', 'Absent'),
(901, '2024-07-30', 'Absent'),
(902, '2024-07-30', 'Absent'),
(903, '2024-07-30', 'Absent'),
(904, '2024-07-30', 'Absent'),
(905, '2024-07-30', 'Absent'),
(906, '2024-07-30', 'Absent'),
(907, '2024-07-30', 'Absent'),
(908, '2024-07-30', 'Absent'),
(909, '2024-07-30', 'Absent'),
(910, '2024-07-30', 'Absent'),
(911, '2024-07-30', 'Absent'),
(912, '2024-07-30', 'Absent'),
(913, '2024-07-30', 'Absent'),
(914, '2024-07-30', 'Absent'),
(915, '2024-07-30', 'Absent'),
(916, '2024-07-30', 'Absent'),
(917, '2024-07-30', 'Absent'),
(918, '2024-07-30', 'Absent'),
(919, '2024-07-30', 'Absent'),
(920, '2024-07-30', 'Absent'),
(921, '2024-07-30', 'Absent'),
(922, '2024-07-30', 'Absent'),
(923, '2024-07-30', 'Absent'),
(924, '2024-07-30', 'Absent'),
(925, '2024-07-30', 'Absent'),
(926, '2024-07-30', 'Absent'),
(927, '2024-07-30', 'Absent'),
(928, '2024-07-30', 'Absent'),
(929, '2024-07-30', 'Absent');

-- --------------------------------------------------------

--
-- Table structure for table `child`
--

CREATE TABLE `child` (
  `childid` varchar(6) NOT NULL,
  `name` text NOT NULL,
  `gender` varchar(1) NOT NULL,
  `classid` varchar(4) NOT NULL,
  `dob` date NOT NULL,
  `images` text DEFAULT 'no.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `child`
--

INSERT INTO `child` (`childid`, `name`, `gender`, `classid`, `dob`, `images`) VALUES
('CH0001', 'Ahmad Seni Aliii', 'M', 'M', '2020-03-10', '1st quarter Impact Report.png'),
('CH0002', 'Alice Johnson', 'F', 'M', '2020-05-15', 'no.png'),
('CH0003', 'Bob Smith', 'M', 'M', '2020-08-22', 'no.png'),
('CH0004', 'Charlie Brown', 'M', 'N', '2019-02-10', 'no.png'),
('CH0005', 'Daisy Miller', 'F', 'N', '2019-11-30', 'no.png'),
('CH0006', 'Ethan Davis', 'M', 'Z', '2018-03-18', 'no.png'),
('CH0007', 'Fiona Garcia', 'F', 'Z', '2018-07-25', 'no.png'),
('CH0008', 'George Clark', 'M', 'Z', '2018-12-05', 'no.png'),
('CH0009', 'James Taylor', 'M', 'Z', '2018-06-15', 'no.png'),
('CH0010', 'Isabella Martinez', 'F', 'M', '2020-05-01', 'no.png'),
('CH0011', 'William Anderson', 'M', 'N', '2019-01-20', 'no.png'),
('CH0012', 'Sophia Thomas', 'F', 'Z', '2018-07-05', 'no.png'),
('CH0013', 'Charlotte White', 'F', 'M', '2020-09-18', 'no.png'),
('CH0014', 'Alexander Clark', 'M', 'N', '2019-11-02', 'no.png'),
('CH0015', 'Amelia Rodriguez', 'F', 'Z', '2018-03-15', 'no.png'),
('CH0016', 'Michael Lewis', 'M', 'M', '2020-02-10', 'no.png'),
('CH0017', 'Ava Lee', 'F', 'N', '2019-08-25', 'no.png'),
('CH0018', 'Ethan Walker', 'M', 'Z', '2018-10-20', 'no.png'),
('CH0019', 'Olivia Hall', 'F', 'M', '2020-12-05', 'no.png'),
('CH0020', 'Mason Young', 'M', 'N', '2019-01-15', 'no.png'),
('CH0021', 'Harper Harris', 'F', 'Z', '2018-07-30', 'no.png'),
('CH0022', 'Elijah Nelson', 'M', 'M', '2020-01-05', 'no.png'),
('CH0023', 'Amelia King', 'F', 'N', '2019-05-20', 'no.png'),
('CH0024', 'Aiden Baker', 'M', 'Z', '2018-09-10', 'no.png'),
('CH0025', 'Charlotte Adams', 'F', 'M', '2020-11-25', 'no.png'),
('CH0026', 'Liam Perez', 'M', 'N', '2019-04-08', 'no.png'),
('CH0027', 'Olivia Carter', 'F', 'Z', '2018-06-12', 'no.png'),
('CH0029', 'Ava Ramirez', 'F', 'N', '2019-02-15', 'no.png'),
('CH0030', 'Mason Gray', 'M', 'Z', '2018-04-30', 'no.png'),
('CH0031', 'Amelia James', 'F', 'M', '2020-08-10', 'no.png'),
('CH0032', 'Oliver Watson', 'M', 'N', '2019-10-25', 'no.png'),
('CH0033', 'Sophia Brooks', 'F', 'Z', '2018-01-12', 'no.png'),
('CH0034', 'Logan Bennett', 'M', 'M', '2020-03-30', 'no.png'),
('CH0035', 'Mia Cooper', 'F', 'N', '2019-05-18', 'no.png'),
('CH0036', 'Ethan Richardson', 'M', 'Z', '2018-07-20', 'no.png'),
('CH0037', 'Emily Rivera', 'F', 'M', '2020-09-05', 'no.png'),
('CH0038', 'Benjamin Ward', 'M', 'N', '2019-12-15', 'no.png'),
('CH0039', 'Isabella Torres', 'F', 'N', '2019-02-28', 'no.png'),
('CH0040', 'William Foster', 'M', 'M', '2020-04-10', 'no.png'),
('CH0041', 'Charlotte Murphy', 'F', 'N', '2019-06-25', 'no.png'),
('CH0042', 'Lucas Gonzales', 'M', 'Z', '2018-08-10', 'no.png'),
('CH0043', 'Amelia Moore', 'F', 'M', '2020-11-20', 'no.png'),
('CH0044', 'Mason Morgan', 'M', 'N', '2019-03-05', 'no.png'),
('CH0045', 'Sophia Cooper', 'F', 'Z', '2018-05-18', 'no.png'),
('CH0046', 'Noah Turner', 'M', 'M', '2020-07-30', 'no.png'),
('CH0047', 'Ava Reed', 'F', 'N', '2019-09-15', 'no.png'),
('CH0048', 'Logan Coleman', 'M', 'Z', '2018-12-25', 'no.png'),
('CH0049', 'Olivia Stewart', 'F', 'M', '2020-02-10', 'no.png'),
('CH0050', 'William Hayes', 'M', 'N', '2019-04-25', 'no.png');

-- --------------------------------------------------------

--
-- Table structure for table `childattendance`
--

CREATE TABLE `childattendance` (
  `childattendanceid` int(11) NOT NULL,
  `childid` varchar(6) NOT NULL,
  `attendanceid` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `childattendance`
--

INSERT INTO `childattendance` (`childattendanceid`, `childid`, `attendanceid`) VALUES
(565, 'CH0002', '602'),
(566, 'CH0005', '603'),
(567, 'CH0008', '604'),
(568, 'CH0011', '605'),
(569, 'CH0014', '606'),
(570, 'CH0017', '607'),
(571, 'CH0020', '608'),
(572, 'CH0023', '609'),
(573, 'CH0026', '610'),
(574, 'CH0029', '611'),
(575, 'CH0032', '612'),
(576, 'CH0035', '613'),
(577, 'CH0038', '614'),
(578, 'CH0041', '615'),
(579, 'CH0044', '616'),
(580, 'CH0047', '617'),
(581, 'CH0050', '618'),
(582, 'CH0003', '619'),
(583, 'CH0006', '620'),
(584, 'CH0009', '621'),
(585, 'CH0012', '622'),
(586, 'CH0015', '623'),
(587, 'CH0018', '624'),
(588, 'CH0021', '625'),
(589, 'CH0024', '626'),
(590, 'CH0027', '627'),
(591, 'CH0030', '628'),
(592, 'CH0033', '629'),
(593, 'CH0036', '630'),
(594, 'CH0039', '631'),
(595, 'CH0042', '632'),
(596, 'CH0045', '633'),
(597, 'CH0048', '634'),
(598, 'CH0048', '635'),
(599, 'CH0002', '636'),
(600, 'CH0005', '637'),
(601, 'CH0008', '638'),
(602, 'CH0011', '639'),
(603, 'CH0014', '640'),
(604, 'CH0017', '641'),
(605, 'CH0020', '642'),
(606, 'CH0023', '643'),
(607, 'CH0026', '644'),
(608, 'CH0029', '645'),
(609, 'CH0032', '646'),
(610, 'CH0035', '647'),
(611, 'CH0038', '648'),
(612, 'CH0041', '649'),
(613, 'CH0044', '650'),
(614, 'CH0047', '651'),
(615, 'CH0050', '652'),
(616, 'CH0003', '653'),
(617, 'CH0006', '654'),
(618, 'CH0009', '655'),
(619, 'CH0012', '656'),
(620, 'CH0015', '657'),
(621, 'CH0018', '658'),
(622, 'CH0021', '659'),
(623, 'CH0024', '660'),
(624, 'CH0027', '661'),
(625, 'CH0030', '662'),
(626, 'CH0033', '663'),
(627, 'CH0036', '664'),
(628, 'CH0039', '665'),
(629, 'CH0042', '666'),
(630, 'CH0045', '667'),
(631, 'CH0048', '668'),
(632, 'CH0001', '669'),
(633, 'CH0004', '670'),
(634, 'CH0007', '671'),
(635, 'CH0010', '672'),
(636, 'CH0013', '673'),
(637, 'CH0016', '674'),
(638, 'CH0019', '675'),
(639, 'CH0022', '676'),
(640, 'CH0025', '677'),
(641, 'CH0028', '678'),
(642, 'CH0031', '679'),
(643, 'CH0034', '680'),
(644, 'CH0037', '681'),
(645, 'CH0040', '682'),
(646, 'CH0043', '683'),
(647, 'CH0046', '684'),
(648, 'CH0049', '685'),
(649, 'CH0051', '686'),
(650, 'CH0002', '687'),
(651, 'CH0005', '688'),
(652, 'CH0008', '689'),
(653, 'CH0011', '690'),
(654, 'CH0014', '691'),
(655, 'CH0017', '692'),
(656, 'CH0020', '693'),
(657, 'CH0023', '694'),
(658, 'CH0026', '695'),
(659, 'CH0029', '696'),
(660, 'CH0032', '697'),
(661, 'CH0035', '698'),
(662, 'CH0038', '699'),
(663, 'CH0041', '700'),
(664, 'CH0044', '701'),
(665, 'CH0047', '702'),
(666, 'CH0050', '703'),
(667, 'CH0002', '704'),
(668, 'CH0005', '705'),
(669, 'CH0008', '706'),
(670, 'CH0011', '707'),
(671, 'CH0014', '708'),
(672, 'CH0017', '709'),
(673, 'CH0020', '710'),
(674, 'CH0023', '711'),
(675, 'CH0026', '712'),
(676, 'CH0029', '713'),
(677, 'CH0032', '714'),
(678, 'CH0035', '715'),
(679, 'CH0038', '716'),
(680, 'CH0041', '717'),
(681, 'CH0044', '718'),
(682, 'CH0047', '719'),
(683, 'CH0050', '720'),
(684, 'CH0002', '721'),
(685, 'CH0005', '722'),
(686, 'CH0008', '723'),
(687, 'CH0011', '724'),
(688, 'CH0014', '725'),
(689, 'CH0017', '726'),
(690, 'CH0020', '727'),
(691, 'CH0023', '728'),
(692, 'CH0026', '729'),
(693, 'CH0029', '730'),
(694, 'CH0032', '731'),
(695, 'CH0035', '732'),
(696, 'CH0038', '733'),
(697, 'CH0041', '734'),
(698, 'CH0044', '735'),
(699, 'CH0047', '736'),
(700, 'CH0050', '737'),
(701, 'CH0011', '738'),
(702, 'CH0014', '739'),
(703, 'CH0017', '740'),
(704, 'CH0020', '741'),
(705, 'CH0023', '742'),
(706, 'CH0026', '743'),
(707, 'CH0029', '744'),
(708, 'CH0032', '745'),
(709, 'CH0035', '746'),
(710, 'CH0038', '747'),
(711, 'CH0039', '748'),
(712, 'CH0041', '749'),
(713, 'CH0044', '750'),
(714, 'CH0047', '751'),
(715, 'CH0050', '752'),
(716, 'CH0001', '753'),
(717, 'CH0002', '754'),
(718, 'CH0003', '755'),
(719, 'CH0010', '756'),
(720, 'CH0013', '757'),
(721, 'CH0016', '758'),
(722, 'CH0019', '759'),
(723, 'CH0022', '760'),
(724, 'CH0025', '761'),
(725, 'CH0031', '762'),
(726, 'CH0034', '763'),
(727, 'CH0037', '764'),
(728, 'CH0040', '765'),
(729, 'CH0043', '766'),
(730, 'CH0046', '767'),
(731, 'CH0049', '768'),
(732, 'CH0051', '769'),
(733, 'CH0052', '770'),
(734, 'CH0001', '771'),
(735, 'CH0002', '772'),
(736, 'CH0003', '773'),
(737, 'CH0010', '774'),
(738, 'CH0013', '775'),
(739, 'CH0016', '776'),
(740, 'CH0019', '777'),
(741, 'CH0022', '778'),
(742, 'CH0025', '779'),
(743, 'CH0031', '780'),
(744, 'CH0034', '781'),
(745, 'CH0037', '782'),
(746, 'CH0040', '783'),
(747, 'CH0043', '784'),
(748, 'CH0046', '785'),
(749, 'CH0049', '786'),
(750, 'CH0051', '787'),
(751, 'CH0052', '788'),
(752, 'CH0001', '789'),
(753, 'CH0002', '790'),
(754, 'CH0003', '791'),
(755, 'CH0010', '792'),
(756, 'CH0013', '793'),
(757, 'CH0016', '794'),
(758, 'CH0019', '795'),
(759, 'CH0022', '796'),
(760, 'CH0025', '797'),
(761, 'CH0031', '798'),
(762, 'CH0034', '799'),
(763, 'CH0037', '800'),
(764, 'CH0040', '801'),
(765, 'CH0043', '802'),
(766, 'CH0046', '803'),
(767, 'CH0049', '804'),
(768, 'CH0051', '805'),
(769, 'CH0052', '806'),
(770, 'CH0001', '807'),
(771, 'CH0002', '808'),
(772, 'CH0003', '809'),
(773, 'CH0010', '810'),
(774, 'CH0013', '811'),
(775, 'CH0016', '812'),
(776, 'CH0019', '813'),
(777, 'CH0022', '814'),
(778, 'CH0025', '815'),
(779, 'CH0031', '816'),
(780, 'CH0034', '817'),
(781, 'CH0037', '818'),
(782, 'CH0040', '819'),
(783, 'CH0043', '820'),
(784, 'CH0046', '821'),
(785, 'CH0049', '822'),
(786, 'CH0051', '823'),
(787, 'CH0052', '824'),
(788, 'CH0004', '825'),
(789, 'CH0005', '826'),
(790, 'CH0011', '827'),
(791, 'CH0014', '828'),
(792, 'CH0017', '829'),
(793, 'CH0020', '830'),
(794, 'CH0023', '831'),
(795, 'CH0026', '832'),
(796, 'CH0029', '833'),
(797, 'CH0032', '834'),
(798, 'CH0035', '835'),
(799, 'CH0038', '836'),
(800, 'CH0039', '837'),
(801, 'CH0041', '838'),
(802, 'CH0044', '839'),
(803, 'CH0047', '840'),
(804, 'CH0050', '841'),
(805, 'CH0004', '842'),
(806, 'CH0005', '843'),
(807, 'CH0011', '844'),
(808, 'CH0014', '845'),
(809, 'CH0017', '846'),
(810, 'CH0020', '847'),
(811, 'CH0023', '848'),
(812, 'CH0026', '849'),
(813, 'CH0029', '850'),
(814, 'CH0032', '851'),
(815, 'CH0035', '852'),
(816, 'CH0038', '853'),
(817, 'CH0039', '854'),
(818, 'CH0041', '855'),
(819, 'CH0044', '856'),
(820, 'CH0047', '857'),
(821, 'CH0050', '858'),
(822, 'CH0001', '859'),
(823, 'CH0002', '860'),
(824, 'CH0003', '861'),
(825, 'CH0010', '862'),
(826, 'CH0013', '863'),
(827, 'CH0016', '864'),
(828, 'CH0019', '865'),
(829, 'CH0022', '866'),
(830, 'CH0025', '867'),
(831, 'CH0031', '868'),
(832, 'CH0034', '869'),
(833, 'CH0037', '870'),
(834, 'CH0040', '871'),
(835, 'CH0043', '872'),
(836, 'CH0046', '873'),
(837, 'CH0049', '874'),
(838, 'CH0051', '875'),
(839, 'CH0052', '876'),
(840, 'CH0001', '877'),
(841, 'CH0002', '878'),
(842, 'CH0003', '879'),
(843, 'CH0010', '880'),
(844, 'CH0013', '881'),
(845, 'CH0016', '882'),
(846, 'CH0019', '883'),
(847, 'CH0022', '884'),
(848, 'CH0025', '885'),
(849, 'CH0031', '886'),
(850, 'CH0034', '887'),
(851, 'CH0037', '888'),
(852, 'CH0040', '889'),
(853, 'CH0043', '890'),
(854, 'CH0046', '891'),
(855, 'CH0049', '892'),
(856, 'CH0051', '893'),
(857, 'CH0052', '894'),
(858, 'CH0004', '895'),
(859, 'CH0005', '896'),
(860, 'CH0011', '897'),
(861, 'CH0014', '898'),
(862, 'CH0017', '899'),
(863, 'CH0020', '900'),
(864, 'CH0023', '901'),
(865, 'CH0026', '902'),
(866, 'CH0029', '903'),
(867, 'CH0032', '904'),
(868, 'CH0035', '905'),
(869, 'CH0038', '906'),
(870, 'CH0039', '907'),
(871, 'CH0041', '908'),
(872, 'CH0044', '909'),
(873, 'CH0047', '910'),
(874, 'CH0050', '911'),
(875, 'CH0052', '912'),
(876, 'CH0001', '913'),
(877, 'CH0002', '914'),
(878, 'CH0003', '915'),
(879, 'CH0010', '916'),
(880, 'CH0013', '917'),
(881, 'CH0016', '918'),
(882, 'CH0019', '919'),
(883, 'CH0022', '920'),
(884, 'CH0025', '921'),
(885, 'CH0031', '922'),
(886, 'CH0034', '923'),
(887, 'CH0037', '924'),
(888, 'CH0040', '925'),
(889, 'CH0043', '926'),
(890, 'CH0046', '927'),
(891, 'CH0049', '928'),
(892, 'CH0051', '929');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `classid` varchar(4) NOT NULL,
  `classname` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`classid`, `classname`) VALUES
('M', 'Mutiara'),
('N', 'Nilam'),
('Z', 'Zamrud');

-- --------------------------------------------------------

--
-- Table structure for table `class_teacher`
--

CREATE TABLE `class_teacher` (
  `id` int(11) NOT NULL,
  `staffid` varchar(6) NOT NULL,
  `classid` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_teacher`
--

INSERT INTO `class_teacher` (`id`, `staffid`, `classid`) VALUES
(25, 'TE0002', 'M'),
(26, 'TE0003', 'M'),
(27, 'TE0004', 'N'),
(28, 'TE0005', 'N'),
(29, 'TE0006', 'Z'),
(30, 'TE0007', 'Z'),
(31, 'TE0008', 'Z'),
(32, 'TE0001', 'N'),
(33, 'TE0001', 'M');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `examID` int(11) NOT NULL,
  `examType` text NOT NULL,
  `classid` varchar(6) NOT NULL,
  `examDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`examID`, `examType`, `classid`, `examDate`) VALUES
(10, 'Ujian 1 666', 'M', '2024-07-09'),
(11, 'Ujian 2', 'M', '2024-07-16'),
(12, 'Ujian 3', 'M', '2024-07-25'),
(13, 'Pertengahan tahun2', 'M', '2024-07-18');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_id` varchar(6) NOT NULL,
  `receiver_id` varchar(6) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender_id`, `receiver_id`, `message`, `timestamp`) VALUES
(40, 'TE0001', 'PA0001', 'testing', '2024-07-09 02:48:12'),
(41, 'PA0001', 'TE0001', 'balas tests', '2024-07-09 03:02:04'),
(42, 'TE0001', 'PA0001', 'awddadawd', '2024-07-12 07:55:46'),
(43, 'TE0001', 'PA0001', 'wadwdwadwdawd', '2024-07-12 07:55:48'),
(44, 'TE0001', 'PA0001', 'hello teacher', '2024-07-15 01:12:30'),
(45, 'TE0001', 'PA0001', 'hello mr hassan', '2024-07-15 01:12:37'),
(46, 'TE0001', 'PA0001', 'test', '2024-07-15 01:13:33'),
(47, 'TE0001', 'PA0001', 'tttt', '2024-07-30 14:05:23'),
(48, 'PA0001', 'TE0002', 'hlooo', '2024-07-30 14:07:27'),
(49, 'PA0001', 'TE0001', 'yes', '2024-07-30 14:07:41'),
(50, 'TE0001', 'PA0001', 'tttdtddd', '2024-07-30 14:21:00'),
(51, 'PA0001', 'TE0001', 'jkjkjkj', '2024-07-30 14:23:20');

-- --------------------------------------------------------

--
-- Table structure for table `parent`
--

CREATE TABLE `parent` (
  `parentid` varchar(6) NOT NULL,
  `parent_name` text NOT NULL,
  `emergencycontact` varchar(12) NOT NULL,
  `workphone` varchar(12) NOT NULL,
  `password` varchar(20) NOT NULL,
  `images` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parent`
--

INSERT INTO `parent` (`parentid`, `parent_name`, `emergencycontact`, `workphone`, `password`, `images`) VALUES
('PA0001', 'Hasan Harith hghfh', '0189065352', '098768564123', '01', 'u3e2l1jt0ar61.jpg'),
('PA0002', 'Ahmad bin Abdullah', '0123456789', '0123456789', 'password1', 'no.png'),
('PA0003', 'Siti binti Ibrahim', '0198765432', '0134567890', 'password2', 'no.png'),
('PA0004', 'Mohd bin Hassan', '0179876543', '0123456789', 'password3', 'no.png'),
('PA0005', 'Nor binti Ahmad', '0134567890', '0198765432', 'password4', 'no.png'),
('PA0006', 'Zainab binti Mohd Yusof', '0167890123', '0179876543', 'password5', 'no.png'),
('PA0007', 'Azman bin Ali', '0145678901', '0167890123', 'password6', 'no.png'),
('PA0008', 'Fatimah binti Abu Bakar', '0123456789', '0145678901', 'password7', 'no.png'),
('PA0009', 'Ismail bin Zainal', '0198765432', '0179876543', 'password8', 'no.png'),
('PA0010', 'Hawa binti Ismail', '0134567890', '0123456789', 'password9', 'no.png'),
('PA0011', 'Rahim bin Mohd Salleh', '0179876543', '0167890123', 'password10', 'no.png'),
('PA0012', 'Zaiton binti Abdul Rahman', '0123456789', '0198765432', 'password11', 'no.png'),
('PA0013', 'Fauzi bin Ahmad', '0145678901', '0134567890', 'password12', 'no.png'),
('PA0014', 'Salmah binti Ismail', '0167890123', '0179876543', 'password13', 'no.png'),
('PA0015', 'Hakim bin Iskandar', '0123456789', '0145678901', 'password14', 'no.png'),
('PA0016', 'Murni binti Mohd Zain', '0198765432', '0134567890', 'password15', 'no.png'),
('PA0017', 'Farid bin Ismail', '0134567890', '0123456789', 'password16', 'no.png'),
('PA0018', 'Zulaikha binti Ahmad', '0167890123', '0198765432', 'password17', 'no.png'),
('PA0019', 'Ahmad bin Mohd Rashid', '0145678901', '0179876543', 'password18', 'no.png'),
('PA0020', 'Noraini binti Aziz', '0179876543', '0167890123', 'password19', 'no.png'),
('PA0021', 'Razif bin Abdullah', '0123456789', '0198765432', 'password20', 'no.png'),
('PA0022', 'Zarina binti Zainal', '0167890123', '0134567890', 'password21', 'no.png'),
('PA0023', 'Hafiz bin Amir', '0198765432', '0145678901', 'password22', 'no.png'),
('PA0024', 'Anisah binti Ariffin', '0134567890', '0179876543', 'password23', 'no.png'),
('PA0025', 'Khalid bin Ali', '0123456789', '0167890123', 'password24', 'no.png'),
('PA0026', 'Nurul binti Khairul', '0179876543', '0134567890', 'password25', 'no.png'),
('PA0027', 'Azhar bin Nasir', '0145678901', '0123456789', 'password26', 'no.png'),
('PA0028', 'Sakinah binti Ismail', '0198765432', '0179876543', 'password27', 'no.png'),
('PA0029', 'Amirul bin Zulkifli', '0134567890', '0167890123', 'password28', 'no.png'),
('PA0030', 'Zalina binti Ahmad', '0123456789', '0145678901', 'password29', 'no.png');

-- --------------------------------------------------------

--
-- Table structure for table `parent_child`
--

CREATE TABLE `parent_child` (
  `id` int(11) NOT NULL,
  `parentid` varchar(6) NOT NULL,
  `childid` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parent_child`
--

INSERT INTO `parent_child` (`id`, `parentid`, `childid`) VALUES
(153, 'PA0003', 'CH0003'),
(154, 'PA0004', 'CH0004'),
(155, 'PA0005', 'CH0005'),
(156, 'PA0006', 'CH0006'),
(157, 'PA0007', 'CH0007'),
(158, 'PA0008', 'CH0008'),
(159, 'PA0009', 'CH0009'),
(160, 'PA0010', 'CH0010'),
(161, 'PA0011', 'CH0011'),
(162, 'PA0012', 'CH0012'),
(163, 'PA0013', 'CH0013'),
(164, 'PA0014', 'CH0014'),
(165, 'PA0015', 'CH0015'),
(166, 'PA0016', 'CH0016'),
(167, 'PA0017', 'CH0017'),
(168, 'PA0018', 'CH0018'),
(169, 'PA0019', 'CH0019'),
(170, 'PA0020', 'CH0020'),
(171, 'PA0021', 'CH0021'),
(172, 'PA0022', 'CH0022'),
(173, 'PA0023', 'CH0023'),
(174, 'PA0024', 'CH0024'),
(175, 'PA0025', 'CH0025'),
(176, 'PA0026', 'CH0026'),
(177, 'PA0027', 'CH0027'),
(178, 'PA0028', 'CH0028'),
(179, 'PA0029', 'CH0029'),
(180, 'PA0030', 'CH0030'),
(181, 'PA0031', 'CH0031'),
(182, 'PA0032', 'CH0032'),
(183, 'PA0033', 'CH0033'),
(184, 'PA0034', 'CH0034'),
(185, 'PA0035', 'CH0035'),
(186, 'PA0036', 'CH0036'),
(187, 'PA0037', 'CH0037'),
(188, 'PA0038', 'CH0038'),
(189, 'PA0039', 'CH0039'),
(190, 'PA0040', 'CH0040'),
(191, 'PA0041', 'CH0041'),
(192, 'PA0042', 'CH0042'),
(193, 'PA0043', 'CH0043'),
(194, 'PA0044', 'CH0044'),
(195, 'PA0045', 'CH0045'),
(196, 'PA0046', 'CH0046'),
(197, 'PA0047', 'CH0047'),
(198, 'PA0048', 'CH0048'),
(199, 'PA0049', 'CH0049'),
(200, 'PA0050', 'CH0050'),
(219, '', 'CH0021'),
(220, 'PA0001', 'CH0002'),
(223, 'PA0022', 'CH0001'),
(224, 'PA0023', 'CH0001'),
(228, 'PA0001', 'CH0015'),
(229, 'PA0001', 'CH0008'),
(230, 'PA0001', 'CH0001');

-- --------------------------------------------------------

--
-- Table structure for table `progress`
--

CREATE TABLE `progress` (
  `progressID` int(11) NOT NULL,
  `childid` varchar(6) NOT NULL,
  `examID` int(11) NOT NULL,
  `examMarks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `progress`
--

INSERT INTO `progress` (`progressID`, `childid`, `examID`, `examMarks`) VALUES
(20, 'CH0001', 10, 100),
(21, 'CH0002', 10, 67),
(22, 'CH0003', 10, 0),
(23, 'CH0010', 10, 0),
(24, 'CH0013', 10, 0),
(25, 'CH0016', 10, 0),
(26, 'CH0019', 10, 0),
(27, 'CH0022', 10, 0),
(28, 'CH0025', 10, 0),
(29, 'CH0031', 10, 0),
(30, 'CH0034', 10, 0),
(31, 'CH0037', 10, 0),
(32, 'CH0040', 10, 0),
(33, 'CH0043', 10, 0),
(34, 'CH0046', 10, 0),
(35, 'CH0049', 10, 0),
(36, 'CH0051', 10, 0),
(37, 'CH0052', 10, 0),
(38, 'CH0001', 11, 99),
(39, 'CH0002', 11, 0),
(40, 'CH0003', 11, 0),
(41, 'CH0010', 11, 0),
(42, 'CH0013', 11, 0),
(43, 'CH0016', 11, 0),
(44, 'CH0019', 11, 0),
(45, 'CH0022', 11, 0),
(46, 'CH0025', 11, 0),
(47, 'CH0031', 11, 0),
(48, 'CH0034', 11, 0),
(49, 'CH0037', 11, 0),
(50, 'CH0040', 11, 0),
(51, 'CH0043', 11, 0),
(52, 'CH0046', 11, 0),
(53, 'CH0049', 11, 0),
(54, 'CH0051', 11, 0),
(55, 'CH0052', 11, 0),
(56, 'CH0001', 12, 56),
(57, 'CH0002', 12, 0),
(58, 'CH0003', 12, 0),
(59, 'CH0010', 12, 0),
(60, 'CH0013', 12, 0),
(61, 'CH0016', 12, 0),
(62, 'CH0019', 12, 0),
(63, 'CH0022', 12, 0),
(64, 'CH0025', 12, 0),
(65, 'CH0031', 12, 0),
(66, 'CH0034', 12, 0),
(67, 'CH0037', 12, 0),
(68, 'CH0040', 12, 0),
(69, 'CH0043', 12, 0),
(70, 'CH0046', 12, 0),
(71, 'CH0049', 12, 0),
(72, 'CH0051', 12, 0),
(73, 'CH0052', 12, 0),
(74, 'CH0001', 13, 70),
(75, 'CH0002', 13, 89),
(76, 'CH0003', 13, 1),
(77, 'CH0010', 13, 99),
(78, 'CH0013', 13, 0),
(79, 'CH0016', 13, 0),
(80, 'CH0019', 13, 0),
(81, 'CH0022', 13, 0),
(82, 'CH0025', 13, 0),
(83, 'CH0031', 13, 0),
(84, 'CH0034', 13, 0),
(85, 'CH0037', 13, 0),
(86, 'CH0040', 13, 0),
(87, 'CH0043', 13, 0),
(88, 'CH0046', 13, 0),
(89, 'CH0049', 13, 0),
(90, 'CH0051', 13, 0);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffid` varchar(6) NOT NULL,
  `qualification` text NOT NULL,
  `password` varchar(20) NOT NULL,
  `role` varchar(10) NOT NULL,
  `name` text NOT NULL,
  `images` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffid`, `qualification`, `password`, `role`, `name`, `images`) VALUES
('AD0001', 'Degree In Computer Science', '01', 'Admin', 'Siti Amelia Adalia Abshari', 'ad1.jpg'),
('TE0001', 'Ke Gua Esport', '01', 'Teacher', 'Cikgu Jamilah', 'te01.jpg'),
('TE0002', 'Doktor Langit', '01', 'Teacher', 'Yun Ji Istadori', 'gambarcikgu2.jpg'),
('TE0003', 'Bachelor of Education', '01', 'Teacher', 'John Smith', 'no.png'),
('TE0004', 'Master of Education', '01', 'Teacher', 'Emily Johnson', 'no.png'),
('TE0005', 'Bachelor of Early Childhood Education', '01', 'Teacher', 'Michael Brown', 'no.png'),
('TE0006', 'Bachelor of Arts in Elementary Education', '01', 'Teacher', 'Sarah Davis', 'no.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`activityID`);

--
-- Indexes for table `activity_child`
--
ALTER TABLE `activity_child`
  ADD PRIMARY KEY (`acID`);

--
-- Indexes for table `activity_teacher`
--
ALTER TABLE `activity_teacher`
  ADD PRIMARY KEY (`atID`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendanceid`);

--
-- Indexes for table `child`
--
ALTER TABLE `child`
  ADD PRIMARY KEY (`childid`);

--
-- Indexes for table `childattendance`
--
ALTER TABLE `childattendance`
  ADD PRIMARY KEY (`childattendanceid`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`classid`);

--
-- Indexes for table `class_teacher`
--
ALTER TABLE `class_teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`examID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parent`
--
ALTER TABLE `parent`
  ADD PRIMARY KEY (`parentid`);

--
-- Indexes for table `parent_child`
--
ALTER TABLE `parent_child`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `progress`
--
ALTER TABLE `progress`
  ADD PRIMARY KEY (`progressID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `activityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `activity_child`
--
ALTER TABLE `activity_child`
  MODIFY `acID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `activity_teacher`
--
ALTER TABLE `activity_teacher`
  MODIFY `atID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendanceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=930;

--
-- AUTO_INCREMENT for table `childattendance`
--
ALTER TABLE `childattendance`
  MODIFY `childattendanceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=893;

--
-- AUTO_INCREMENT for table `class_teacher`
--
ALTER TABLE `class_teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `examID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `parent_child`
--
ALTER TABLE `parent_child`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `progress`
--
ALTER TABLE `progress`
  MODIFY `progressID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
